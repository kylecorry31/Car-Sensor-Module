# kalman-filter
 A simple, single sensor Kalman Filter for Arduinos
